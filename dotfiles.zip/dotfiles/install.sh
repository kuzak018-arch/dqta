#!/usr/bin/env bash
# Разворачивает настройку на чистой системе.  bash install.sh
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP=$(date +%Y%m%d-%H%M%S)
say() { printf '\n\033[1;35m==>\033[0m %s\n' "$1"; }

if ! command -v pacman >/dev/null; then
    echo "Этот скрипт для Arch и производных (нужен pacman)."; exit 1
fi

say "Ставлю программы из репозиториев"
sudo pacman -Syu --needed --noconfirm - < "$SRC/pkglist.txt"

say "Копирую конфиги"
mkdir -p "$HOME/.config" "$HOME/.local/bin"

for d in "$SRC"/config/*/; do
    NAME=$(basename "$d")
    if [ -e "$HOME/.config/$NAME" ]; then
        mv "$HOME/.config/$NAME" "$HOME/.config/$NAME.bak-$STAMP"
        echo "    старое сохранено: .config/$NAME.bak-$STAMP"
    fi
    cp -r "$d" "$HOME/.config/"
    echo "    .config/$NAME"
done

cp -r "$SRC"/local/bin/. "$HOME/.local/bin/" 2>/dev/null || true
chmod +x "$HOME"/.local/bin/* 2>/dev/null || true

say "Подставляю твой домашний путь"
find "$HOME/.config" "$HOME/.local/bin" -type f -print0 2>/dev/null \
    | xargs -0 -r grep -lZ '__HOME__' 2>/dev/null \
    | xargs -0 -r sed -i "s|__HOME__|$HOME|g" || true

if [ -f "$SRC/bashrc" ]; then
    [ -f "$HOME/.bashrc" ] && cp "$HOME/.bashrc" "$HOME/.bashrc.bak-$STAMP"
    cp "$SRC/bashrc" "$HOME/.bashrc"
    echo "    .bashrc"
fi

mkdir -p "$HOME/Pictures/walls" "$HOME/Pictures/screenshots"

say "Проверяю конфиг niri"
if command -v niri >/dev/null; then
    niri validate && echo "    конфиг в порядке"
else
    echo "    niri ещё не установлен, проверка пропущена"
fi

if [ -s "$SRC/pkglist-aur.txt" ]; then
cat <<AUR

---------------------------------------------------------------
  Осталось поставить пакеты из AUR. Их список:

$(sed 's/^/    /' "$SRC/pkglist-aur.txt")

  Если есть помощник (paru или yay):
      paru -S --needed $(tr '\n' ' ' < "$SRC/pkglist-aur.txt")

  Если нет — руками, по одному:
      git clone https://aur.archlinux.org/ИМЯ.git ~/build/ИМЯ
      cd ~/build/ИМЯ && makepkg -si
---------------------------------------------------------------
AUR
fi

cat <<'DONE'

=====================================================================
  Готово. Запусти niri:   niri --session
  Обои появятся после:    getwall 20 && wall
=====================================================================
DONE
