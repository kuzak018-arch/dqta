#!/usr/bin/env bash
# =====================================================================
#  dotsave.sh — собирает всю твою настройку в папку ~/dotfiles
#  Запускать в линуксе:  bash dotsave.sh
# =====================================================================
set -euo pipefail

DOTS="$HOME/dotfiles"
say() { printf '\n\033[1;35m==>\033[0m %s\n' "$1"; }

say "Собираю конфиги в $DOTS"
rm -rf "$DOTS"
mkdir -p "$DOTS"/{config,local/bin}

# ---- конфиги программ ----
for d in niri waybar alacritty fuzzel mako imv cava fontconfig gtk-3.0 gtk-4.0; do
    if [ -d "$HOME/.config/$d" ]; then
        cp -r "$HOME/.config/$d" "$DOTS/config/"
        echo "    config/$d"
    fi
done

# ---- свои команды ----
for f in wall getwall livewall fromwin towin; do
    if [ -f "$HOME/.local/bin/$f" ]; then
        cp "$HOME/.local/bin/$f" "$DOTS/local/bin/"
        echo "    local/bin/$f"
    fi
done

# ---- настройки шелла ----
[ -f "$HOME/.bashrc" ] && cp "$HOME/.bashrc" "$DOTS/bashrc" && echo "    bashrc"

# ---- списки пакетов ----
say "Записываю списки установленных программ"
pacman -Qqen > "$DOTS/pkglist.txt"
pacman -Qqem > "$DOTS/pkglist-aur.txt"
echo "    из репозиториев: $(wc -l < "$DOTS/pkglist.txt") шт."
echo "    из AUR:          $(wc -l < "$DOTS/pkglist-aur.txt") шт."

# ---- убираем личные пути, чтобы работало под любым именем ----
say "Обезличиваю пути"
find "$DOTS/config" "$DOTS/local" -type f -print0 2>/dev/null \
    | xargs -0 -r sed -i "s|$HOME|__HOME__|g" || true

# =====================================================================
#  Скрипт восстановления, который поедет вместе с конфигами
# =====================================================================
cat > "$DOTS/install.sh" <<'INSTALL_EOF'
#!/usr/bin/env bash
# Разворачивает настройку на чистой системе.  bash install.sh
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP=$(date +%Y%m%d-%H%M%S)
say() { printf '\n\033[1;35m==>\033[0m %s\n' "$1"; }

if ! command -v pacman >/dev/null; then
    echo "Этот скрипт для Arch и производных (нужен pacman)."; exit 1
fi

say "Ставлю программы из репозиториев"
sudo pacman -Syu --needed --noconfirm - < "$SRC/pkglist.txt"

say "Копирую конфиги"
mkdir -p "$HOME/.config" "$HOME/.local/bin"

for d in "$SRC"/config/*/; do
    NAME=$(basename "$d")
    if [ -e "$HOME/.config/$NAME" ]; then
        mv "$HOME/.config/$NAME" "$HOME/.config/$NAME.bak-$STAMP"
        echo "    старое сохранено: .config/$NAME.bak-$STAMP"
    fi
    cp -r "$d" "$HOME/.config/"
    echo "    .config/$NAME"
done

cp -r "$SRC"/local/bin/. "$HOME/.local/bin/" 2>/dev/null || true
chmod +x "$HOME"/.local/bin/* 2>/dev/null || true

say "Подставляю твой домашний путь"
find "$HOME/.config" "$HOME/.local/bin" -type f -print0 2>/dev/null \
    | xargs -0 -r grep -lZ '__HOME__' 2>/dev/null \
    | xargs -0 -r sed -i "s|__HOME__|$HOME|g" || true

if [ -f "$SRC/bashrc" ]; then
    [ -f "$HOME/.bashrc" ] && cp "$HOME/.bashrc" "$HOME/.bashrc.bak-$STAMP"
    cp "$SRC/bashrc" "$HOME/.bashrc"
    echo "    .bashrc"
fi

mkdir -p "$HOME/Pictures/walls" "$HOME/Pictures/screenshots"

say "Проверяю конфиг niri"
if command -v niri >/dev/null; then
    niri validate && echo "    конфиг в порядке"
else
    echo "    niri ещё не установлен, проверка пропущена"
fi

if [ -s "$SRC/pkglist-aur.txt" ]; then
cat <<AUR

---------------------------------------------------------------
  Осталось поставить пакеты из AUR. Их список:

$(sed 's/^/    /' "$SRC/pkglist-aur.txt")

  Если есть помощник (paru или yay):
      paru -S --needed $(tr '\n' ' ' < "$SRC/pkglist-aur.txt")

  Если нет — руками, по одному:
      git clone https://aur.archlinux.org/ИМЯ.git ~/build/ИМЯ
      cd ~/build/ИМЯ && makepkg -si
---------------------------------------------------------------
AUR
fi

cat <<'DONE'

=====================================================================
  Готово. Запусти niri:   niri --session
  Обои появятся после:    getwall 20 && wall
=====================================================================
DONE
INSTALL_EOF

chmod +x "$DOTS/install.sh"

# =====================================================================
cat > "$DOTS/README.md" <<'README_EOF'
# Мои дотфайлы

Настройка рабочего стола на **niri** для Arch Linux: блюр,
полупрозрачность, Catppuccin Mocha, качалка обоев, живые обои.

## Что внутри

```
config/          конфиги программ -> ~/.config/
local/bin/       свои команды -> ~/.local/bin/
bashrc           настройки шелла -> ~/.bashrc
pkglist.txt      программы из репозиториев Arch
pkglist-aur.txt  программы из AUR
install.sh       разворачивает всё это на чистой системе
```

## Развернуть на новой машине

Нужен установленный Arch Linux (или EndeavourOS, CachyOS) с интернетом.

```bash
git clone https://github.com/ТВОЙ-НИК/dotfiles.git ~/dotfiles
cd ~/dotfiles
bash install.sh
```

Скрипт поставит программы, скопирует конфиги, а старые сохранит рядом
с суффиксом `.bak-дата`. Пакеты из AUR ставятся отдельно, скрипт
напечатает список и команды в конце.

Потом:

```bash
niri --session
```

## Команды

```bash
getwall 20      скачать аниме-обои
wall            поставить случайную
walls           листать и выбирать (w — поставить, d — удалить)
livewall файл   живые обои из видео
fromwin         забрать текст из буфера Windows (только в виртуалке)
```

## Клавиши

`Mod` — клавиша Win.

| Клавиши | Действие |
|---------|----------|
| `Mod+T` | терминал |
| `Mod+D` | лаунчер |
| `Mod+E` | файловый менеджер |
| `Mod+Q` | закрыть окно |
| `Mod+O` | обзор окон |
| `Mod+S` | скриншот области |
| `Mod+Shift+C` | история буфера обмена |
| `Mod+Shift+/` | все клавиши |
| `Mod+Shift+E` | выйти из niri |

## Обновить слепок после правок

На машине, где настраивал:

```bash
bash dotsave.sh
cd ~/dotfiles && git add -A && git commit -m "обновил конфиги" && git push
```
README_EOF

# ---- .gitignore на всякий ----
cat > "$DOTS/.gitignore" <<'GI_EOF'
*.bak-*
GI_EOF

cp "$0" "$DOTS/dotsave.sh" 2>/dev/null || true

cat <<DONE

=====================================================================
  Готово. Всё лежит в $DOTS

  Посмотреть:
      ls -R ~/dotfiles

  Быстрый бэкап одним файлом:
      tar czf ~/dotfiles.tar.gz -C ~ dotfiles

  Выложить на GitHub (инструкция в README.md):
      cd ~/dotfiles
      git init -b main
      git add -A
      git commit -m "мои дотфайлы"
      git remote add origin https://github.com/ТВОЙ-НИК/dotfiles.git
      git push -u origin main
=====================================================================
DONE
