#!/usr/bin/env bash
# install.sh — разворачивает рейс «ash» на чистом Arch.
#
# Идемпотентен: одинаковые файлы пропускает молча, различающиеся —
# только с твоего подтверждения, перед перезаписью кладёт .bak-<дата>.
#
#   ./install.sh              обычный прогон
#   ./install.sh --dry-run    показать, что сделал бы, ничего не трогая
#   ./install.sh --force      перезаписывать без вопросов (бэкапы всё равно делаются)
#   ./install.sh --no-packages   только конфиги, пакеты не ставить

set -uo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"

DRY=0
FORCE=0
DO_PACKAGES=1
OVERWRITE_ALL=0
SKIP_ALL=0

for arg in "$@"; do
  case "$arg" in
    --dry-run)     DRY=1 ;;
    --force)       FORCE=1; OVERWRITE_ALL=1 ;;
    --no-packages) DO_PACKAGES=0 ;;
    -h|--help)     sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "Неизвестный аргумент: $arg" >&2; exit 1 ;;
  esac
done

# ---------------------------------------------------------------- вывод ----
c_ok=$'\e[32m'; c_skip=$'\e[90m'; c_warn=$'\e[33m'; c_err=$'\e[31m'; c_hdr=$'\e[1m'; c_off=$'\e[0m'
say()  { printf '%s\n' "$*"; }
hdr()  { printf '\n%s== %s%s\n' "$c_hdr" "$*" "$c_off"; }
ok()   { printf '  %sok%s    %s\n' "$c_ok" "$c_off" "$*"; }
skip() { printf '  %s--%s    %s\n' "$c_skip" "$c_off" "$*"; }
warn() { printf '  %s!!%s    %s\n' "$c_warn" "$c_off" "$*"; }
err()  { printf '  %sXX%s    %s\n' "$c_err" "$c_off" "$*"; }

run() { if [ "$DRY" = 1 ]; then printf '  %s(dry)%s %s\n' "$c_skip" "$c_off" "$*"; else "$@"; fi; }

# Вопросы задаём через отдельный дескриптор, а не через stdin: install_tree
# крутит `while read < <(find ...)`, где fd 0 занят списком файлов — чтение
# ответа оттуда сожрало бы очередное имя файла. Предпочитаем терминал
# (скрипт могли запустить через pipe), иначе — исходный stdin.
exec 3<&0
ASK_FD=3
if ( : </dev/tty ) 2>/dev/null; then exec 4</dev/tty; ASK_FD=4; fi

# ------------------------------------------------------------ проверки ----
if [ "$(id -u)" = 0 ]; then
  echo "Не запускай от root: конфиги лягут в /root. Запускай обычным пользователем." >&2
  exit 1
fi
command -v pacman >/dev/null || { echo "Это не Arch: pacman не найден." >&2; exit 1; }

# ------------------------------------------------- установка одного файла --
# install_file <источник> <назначение>
#   • нет файла        -> копируем
#   • совпадает        -> молча пропускаем (идемпотентность)
#   • отличается       -> спрашиваем, бэкапим, копируем
install_file() {
  local src="$1" dst="$2" rel="${2#"$HOME"/}"

  if [ ! -e "$dst" ]; then
    run mkdir -p "$(dirname "$dst")"
    run cp -p "$src" "$dst"
    ok "~/$rel"
    return
  fi

  if cmp -s "$src" "$dst"; then
    skip "~/$rel (не изменился)"
    return
  fi

  if [ "$SKIP_ALL" = 1 ]; then
    skip "~/$rel (пропущен)"
    return
  fi

  if [ "$OVERWRITE_ALL" != 1 ]; then
    local ans
    while true; do
      printf '  %s??%s    ~/%s уже есть и отличается. Перезаписать? [y]да / [n]нет / [d]diff / [A]все / [N]ни одного: ' \
        "$c_warn" "$c_off" "$rel"
      # Некого спросить (ни терминала, ни stdin) — чужой файл не трогаем.
      read -r ans <&"$ASK_FD" || { printf '\n'; skip "~/$rel (некого спросить — пропущен)"; return; }
      case "$ans" in
        y|Y|"") break ;;
        n)      skip "~/$rel (пропущен)"; return ;;
        d)      diff -u --color=auto "$dst" "$src" | head -60 || true ;;
        A)      OVERWRITE_ALL=1; break ;;
        N)      SKIP_ALL=1; skip "~/$rel (пропущен)"; return ;;
        *)      say "      не понял, нужно y/n/d/A/N" ;;
      esac
    done
  fi

  run cp -p "$dst" "$dst.bak-$STAMP"
  run cp -p "$src" "$dst"
  ok "~/$rel (старый -> $(basename "$dst").bak-$STAMP)"
}

# install_tree <каталог-источник> <каталог-назначение>
install_tree() {
  local s="$1" d="$2" f rel
  [ -d "$s" ] || return 0
  while IFS= read -r -d '' f; do
    rel="${f#"$s"/}"
    install_file "$f" "$d/$rel"
  done < <(find "$s" -type f -print0 | sort -z)
}

# ============================================================== пакеты ====
if [ "$DO_PACKAGES" = 1 ]; then
  hdr "Пакеты из официальных репозиториев"
  mapfile -t want < <(grep -vE '^\s*(#|$)' "$SRC/pkglist.txt")
  mapfile -t extra < <(sed 's/#.*//' "$SRC/pkglist-extra.txt" | grep -vE '^\s*$' | awk '{print $1}')
  want+=("${extra[@]}")

  missing=()
  for p in "${want[@]}"; do
    pacman -Qq "$p" >/dev/null 2>&1 || missing+=("$p")
  done

  if [ ${#missing[@]} -eq 0 ]; then
    skip "всё уже установлено (${#want[@]} пакетов)"
  else
    say "  не хватает ${#missing[@]} из ${#want[@]}: ${missing[*]}"
    run sudo pacman -S --needed -- "${missing[@]}" || err "pacman завершился с ошибкой, смотри вывод выше"
  fi

  hdr "Пакеты из AUR"
  mapfile -t aur < <(grep -vE '^\s*(#|$)' "$SRC/aurlist.txt")
  aur_missing=()
  for p in "${aur[@]}"; do
    pacman -Qq "$p" >/dev/null 2>&1 || aur_missing+=("$p")
  done

  if [ ${#aur_missing[@]} -eq 0 ]; then
    skip "всё уже установлено (${#aur[@]} пакетов)"
  elif command -v paru >/dev/null; then
    run paru -S --needed -- "${aur_missing[@]}"
  elif command -v yay >/dev/null; then
    run yay -S --needed -- "${aur_missing[@]}"
  else
    warn "AUR-хелпер не найден, поставь вручную: ${aur_missing[*]}"
    say  "      git clone https://aur.archlinux.org/<пакет>.git && cd <пакет> && makepkg -si"
  fi
fi

# ================================================== подстановка путей =====
# В niri, hyprlock и user.js зашит абсолютный /home/fernando — на машине
# с другим пользователем это тихо ломает обои, лок-скрин, лаунчер и дашборд.
# Подставляем путь в промежуточной копии ДО сравнения с установленным:
# если править уже разложенные файлы, они навсегда остаются «отличающимися»
# от репозитория, и скрипт перестаёт быть идемпотентным.
ORIG_HOME=/home/fernando
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

hdr "Пути под текущего пользователя"
cp -a "$SRC/home/." "$STAGE/"
if [ "$HOME" = "$ORIG_HOME" ]; then
  skip "$HOME совпадает с исходным, подстановка не нужна"
else
  mapfile -t patched < <(grep -rl "$ORIG_HOME" "$STAGE" 2>/dev/null)
  if [ ${#patched[@]} -eq 0 ]; then
    skip "нечего подставлять"
  else
    names=()
    for f in "${patched[@]}"; do
      sed -i "s#$ORIG_HOME#$HOME#g" "$f"
      names+=("${f#"$STAGE"/}")
    done
    ok "$ORIG_HOME -> $HOME в ${#names[@]} файлах: ${names[*]}"
  fi
fi

# ============================================================= конфиги ====
hdr "Конфиги в ~"
install_tree "$STAGE" "$HOME"

# ============================================================== обои ======
hdr "Обои"
run mkdir -p "$HOME/Pictures/walls" "$HOME/Pictures/screenshots"
install_file "$SRC/wallpapers/ash-forest.png" "$HOME/Pictures/walls/ash-forest.png"
install_file "$SRC/wallpapers/lock-bg.png"    "$HOME/Pictures/lock-bg.png"

if [ -L "$HOME/Pictures/wall.png" ] && [ "$(readlink -f "$HOME/Pictures/wall.png")" = "$HOME/Pictures/walls/ash-forest.png" ]; then
  skip "Pictures/wall.png (ссылка на месте)"
elif [ -e "$HOME/Pictures/wall.png" ] && [ ! -L "$HOME/Pictures/wall.png" ]; then
  warn "Pictures/wall.png — обычный файл, не трогаю. Замени сам: ln -sfn walls/ash-forest.png ~/Pictures/wall.png"
else
  run ln -sfn "$HOME/Pictures/walls/ash-forest.png" "$HOME/Pictures/wall.png"
  ok "Pictures/wall.png -> walls/ash-forest.png"
fi
say "      Ещё обоев: getwall 15 (качает в ~/Pictures/walls), переключить: wall"

# ============================================================ firefox =====
hdr "Firefox"
profile=""
if [ -f "$HOME/.mozilla/firefox/profiles.ini" ]; then
  ff_root="$HOME/.mozilla/firefox"
elif [ -f "$HOME/.config/mozilla/firefox/profiles.ini" ]; then
  ff_root="$HOME/.config/mozilla/firefox"
else
  ff_root=""
fi

if [ -z "$ff_root" ]; then
  warn "профиль Firefox не найден — запусти Firefox один раз и прогони install.sh снова"
else
  profile="$(find "$ff_root" -maxdepth 1 -type d -name '*.default-release' | head -1)"
  [ -z "$profile" ] && profile="$(find "$ff_root" -maxdepth 1 -type d -name '*.default' | head -1)"
fi

if [ -n "$profile" ]; then
  # user.js тоже через staging: в нём путь к стартовой странице.
  mkdir -p "$STAGE/.firefox"
  cp -a "$SRC/firefox/." "$STAGE/.firefox/"
  [ "$HOME" != "$ORIG_HOME" ] && sed -i "s#$ORIG_HOME#$HOME#g" "$STAGE/.firefox/user.js"
  install_file "$STAGE/.firefox/user.js" "$profile/user.js"
  install_file "$STAGE/.firefox/chrome/userChrome.css"   "$profile/chrome/userChrome.css"
  install_file "$STAGE/.firefox/chrome/userContent.css"  "$profile/chrome/userContent.css"
  say "      Стартовая страница включится после перезапуска Firefox"
elif [ -n "$ff_root" ]; then
  warn "каталог профиля не опознан в $ff_root — скопируй firefox/ вручную"
fi

# ======================================================= иконки, курсор ===
hdr "Иконочная тема Papirus-Ash"
if [ -d "$HOME/.local/share/icons/Papirus-Ash" ] && [ -d "$HOME/.local/share/icons/Papirus-Ash-Dark" ]; then
  skip "уже собрана (пересобрать: rice-icons)"
elif [ ! -d /usr/share/icons/Papirus ]; then
  warn "нет papirus-icon-theme — поставь его и запусти rice-icons"
else
  run chmod +x "$HOME/.local/bin/rice-icons"
  run "$HOME/.local/bin/rice-icons" && ok "собрана" || err "rice-icons упал, запусти вручную"
fi

hdr "Курсор Bibata-Modern-Ice"
if [ -d "$HOME/.local/share/icons/Bibata-Modern-Ice" ] || [ -d /usr/share/icons/Bibata-Modern-Ice ]; then
  skip "на месте"
else
  warn "не установлен, а на него ссылаются niri и gtk-темы"
  say  "      AUR: bibata-cursor-theme-bin"
  say  "      или вручную: https://github.com/ful1e5/Bibata_Cursor/releases -> ~/.local/share/icons/"
fi

# ============================================================== права =====
hdr "Права на скрипты"
if [ "$DRY" != 1 ]; then
  chmod +x "$HOME"/.local/bin/{rice-theme,rice-launcher,rice-dash,rice-clock,rice-icons,wall,getwall,livewall} 2>/dev/null
fi
ok "~/.local/bin/* исполняемые"

# ============================================================== финал =====
hdr "Готово"
cat <<EOF
  Дальше:
    1. Перелогинься в сессию niri (sddm -> Niri), или Mod+Shift+E для перезапуска.
    2. Тема: rice-theme light | rice-theme dark | rice-theme toggle (Mod+Shift+T)
    3. Шпаргалка по клавишам: Mod+Shift+/

  Если что-то перезаписалось зря — рядом лежат копии *.bak-$STAMP
EOF

if [ "$DRY" = 1 ]; then
  say ""
  warn "это был --dry-run, на диске ничего не изменилось"
fi
