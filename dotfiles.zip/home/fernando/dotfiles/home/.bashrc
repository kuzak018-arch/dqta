#
# ~/.bashrc
#

# If not running interactively, don't do anything
[[ $- != *i* ]] && return

alias ls='ls --color=auto'
alias grep='grep --color=auto'
PS1='[\u@\h \W]\$ '
export PATH="$HOME/.local/bin:$PATH"
eval "$(starship init bash)"
eval "$(zoxide init bash)"
alias ls='eza --icons --group-directories-first'
alias ll='eza -l --icons --git'
alias cat='bat -p'
alias cd='z'
