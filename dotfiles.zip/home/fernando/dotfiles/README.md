# dotfiles — Arch + niri, рейс «ash»

Бело-серый минималистичный сетап: прокручивающийся тайлинг [niri](https://github.com/YaLTeR/niri)
на Wayland, акрил/блюр под окнами, светлая и тёмная версии одной палитры.
Собрано в VirtualBox, рассчитано на перенос на физический ноутбук.

Вся палитра генерируется скриптом `rice-theme`: он переписывает цвета сразу
в niri, waybar, alacritty, mako, fuzzel, btop, yazi, tmux, cava, GTK и xsettingsd,
так что тема везде одна и та же. Руками цвета в конфигах не правь — перезапишутся.

## Стек

| Роль | Программа |
|---|---|
| Композитор / WM | `niri` |
| Панель | `waybar` |
| Лаунчер | `fuzzel` + свой `rice-launcher` |
| Терминал | `alacritty` |
| Уведомления | `mako` |
| Обои | `swaybg`, видео-обои — `mpvpaper` |
| Блокировка | `hyprlock` |
| Файлы | `nemo` (GUI), `yazi` (TUI) |
| Буфер обмена | `cliphist` + `wl-clipboard` |
| Скриншоты | `grim` + `slurp` |
| Звук | `pipewire` / `wireplumber`, `pavucontrol` |
| Монитор | `btop`, дашборд `rice-dash` в `tmux` |
| X11-приложения | `xwayland-satellite` |
| Оболочка | `bash` + `starship`, `zoxide`, `eza`, `bat`, `fd`, `fzf` |
| Шрифты | Inter (UI), JetBrains Mono Nerd (моно) |
| Иконки | Papirus-Ash — серый Papirus, собирается `rice-icons` |
| Курсор | Bibata-Modern-Ice |

## Что в репозитории

```
home/           зеркало ~, раскладывается как есть (.config/*, .local/bin/*, .bashrc)
firefox/        user.js + userChrome.css — кладутся в каталог профиля, а не в ~
wallpapers/     обои, которые стоят сейчас: ash-forest.png и lock-bg.png
pkglist.txt     пакеты из официальных репозиториев (pacman -Qqen)
aurlist.txt     пакеты из AUR (pacman -Qqem)
pkglist-extra.txt  нужные пакеты, которые стоят как зависимости и в -Qqen не попали
install.sh      разворачивает всё это на чистой машине
```

## Установка на чистый Arch

Нужна уже работающая базовая система с сетью и `sudo`.

```sh
git clone <этот-репозиторий> ~/dotfiles
cd ~/dotfiles
./install.sh --dry-run    # посмотреть, что произойдёт, ничего не меняя
./install.sh
```

Скрипт:

1. доставляет недостающие пакеты из `pkglist.txt` и `pkglist-extra.txt`;
2. ставит AUR-пакеты, если найдёт `paru` или `yay` (иначе просто скажет, что собрать руками);
3. подставляет актуальный `$HOME` вместо зашитого `/home/fernando`
   в `niri/config.kdl`, `hypr/hyprlock.conf` и `firefox/user.js`;
4. раскладывает конфиги по `~`;
5. кладёт обои и делает ссылку `~/Pictures/wall.png`;
6. находит профиль Firefox и кладёт в него `user.js` и `chrome/`;
7. собирает иконочную тему Papirus-Ash через `rice-icons`.

Он **идемпотентен**: одинаковые файлы пропускает молча, а перед перезаписью
отличающихся — спрашивает и складывает рядом `*.bak-<дата>`.

Флаги: `--dry-run`, `--force` (не спрашивать), `--no-packages` (только конфиги).

После установки перелогинься в сессию niri (в sddm выбрать Niri).

### Что придётся доделать руками

- **Курсор Bibata-Modern-Ice** в репозиторий не положен (27 МБ) — ставится из AUR
  (`bibata-cursor-theme-bin`) или [релизов на GitHub](https://github.com/ful1e5/Bibata_Cursor/releases)
  в `~/.local/share/icons/`. Без него niri и GTK откатятся на системный курсор.
- **Иконки Papirus-Ash** генерируются из `papirus-icon-theme`, в репозитории их нет.
  `install.sh` вызывает `rice-icons` сам; после каждого обновления
  `papirus-icon-theme` тему надо пересобирать той же командой.
- **Обои**: в репозитории только текущие две. Остальные качает `getwall 15`.
- **AUR**: AUR-хелпер не установлен, `mpvpaper` собирался руками через `makepkg -si`.

### Особенности переноса с виртуалки

- Из `pkglist.txt` убран `virtualbox-guest-utils` — на железе он не нужен.
- В `niri/config.kdl` секция `output "Virtual-1"` описывает виртуальный монитор
  VirtualBox. На ноутбуке вывод будет называться иначе (`eDP-1`), так что эту
  секцию надо переименовать, а для HiDPI-экрана поставить `scale 1.5` или `2.0`.
  Список выводов: `niri msg outputs`.
- Драйверы GPU в списке стоят «на все случаи» (`vulkan-intel`, `vulkan-radeon`,
  `vulkan-nouveau`, `xf86-video-*`). Лишние для конкретного железа можно убрать.
- `plasma-meta` и `sddm` тянут за собой KDE. Конфиги KDE в репозиторий
  сознательно не попали — они конфликтуют с рейсом. Если KDE не нужен,
  убери `plasma-meta`, `konsole`, `kvantum` из `pkglist.txt`, но тогда проверь,
  что `pipewire`, `wireplumber`, `playerctl` и `xdg-desktop-portal-gtk`
  встанут явно — они перечислены в `pkglist-extra.txt` как раз для этого.
- Для ноутбука пригодится то, чего в виртуалке не было: `tlp` или `power-profiles-daemon`,
  `brightnessctl` (в niri нет биндов яркости — их надо дописать),
  `iwd`/`bluez` при необходимости.

## Горячие клавиши

`Mod` — это Super (Win). Полная шпаргалка в самом niri: **Mod+Shift+/**.

| Клавиши | Действие |
|---|---|
| `Mod+T` | терминал |
| `Mod+D` | лаунчер |
| `Mod+E` / `Mod+Alt+E` | nemo / yazi |
| `Mod+G` | дашборд |
| `Mod+B` | btop |
| `Mod+Q` | закрыть окно |
| `Mod+O` | обзор рабочих столов |
| `Mod+Shift+C` | история буфера обмена |
| `Mod+Shift+T` | переключить светлую/тёмную тему |
| `Super+Alt+L` | заблокировать экран |
| `Mod+S` / `Print` | скриншот |
| `Mod+Shift+E` | выйти из сессии |

Раскладка переключается `Alt+Shift` (us/ru).

## Свои скрипты (`~/.local/bin`)

| Скрипт | Что делает |
|---|---|
| `rice-theme` | генерирует палитру и переписывает все конфиги; `light` / `dark` / `toggle` |
| `rice-icons` | собирает иконочные темы Papirus-Ash и Papirus-Ash-Dark |
| `rice-launcher` | лаунчер поверх fuzzel |
| `rice-dash` | дашборд в tmux |
| `rice-clock` | часы для дашборда |
| `wall` | переключить обои |
| `getwall` | скачать обои в `~/Pictures/walls` |
| `livewall` | видео-обои через mpvpaper |
