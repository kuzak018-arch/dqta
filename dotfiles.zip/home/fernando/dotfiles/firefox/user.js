// ash :: настройки Firefox
// user.js читается при каждом старте и переопределяет prefs.js.
// ВАЖНО: значения отсюда впечатываются в prefs.js навсегда. Если убрать
// строку из этого файла, старое значение НЕ вернётся — его надо будет
// либо прописать здесь явно, либо сбросить в about:config.

// ---------------------------------------------------- кастомизация ------
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

// ---------------------------------------------------- стартовая ---------
user_pref("browser.startup.page", 1);
user_pref("browser.startup.homepage", "file:///home/fernando/.config/firefox-start/index.html");

// ---------------------------------------------------- новая вкладка -----
// Спонсорские плитки, Pocket-стори и «рекомендации» на about:newtab
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false);
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.feeds.topsites", false);
user_pref("browser.newtabpage.activity-stream.system.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.discoverystream.enabled", false);
user_pref("extensions.pocket.enabled", false);

// ---------------------------------------------------- телеметрия --------
user_pref("toolkit.telemetry.enabled", false);
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false);
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false);
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false);
user_pref("toolkit.telemetry.updatePing.enabled", false);
user_pref("toolkit.telemetry.bhrPing.enabled", false);
user_pref("toolkit.telemetry.coverage.opt-out", true);
user_pref("datareporting.healthreport.uploadEnabled", false);
user_pref("datareporting.policy.dataSubmissionEnabled", false);
user_pref("browser.ping-centre.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);

// ---------------------------------------------------- эксперименты ------
user_pref("app.shield.optoutstudies.enabled", false);
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");
user_pref("browser.discovery.enabled", false);

// ---------------------------------------------------- мелочи -----------
user_pref("browser.uitour.enabled", false);            // всплывающие туры
user_pref("browser.aboutConfig.showWarning", false);   // «я буду осторожен»
user_pref("browser.tabs.warnOnClose", false);
user_pref("browser.compactmode.show", true);           // включает «Компактно» в настройках плотности
